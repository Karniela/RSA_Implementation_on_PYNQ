#include "ap_int.h"

#ifndef RSA_H_
#define RSA_H_

#define NUM_SAMPLES 100


typedef ap_uint<1024> data_t;

void rsa(data_t d, data_t N, data_t y, data_t &x);
#endif
