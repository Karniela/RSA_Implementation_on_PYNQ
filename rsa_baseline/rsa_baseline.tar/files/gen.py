from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
import random
# Generate RSA key pair with 128-bit modulus
file_length = 100
key = RSA.generate(1024)

# Extract the components
p = key.p
q = key.q
n = key.n
e = key.e
d = key.d

# Print the values
print(f"p: {p}")
print(f"q: {q}")
print(f"n: {n}")
print(f"e: {e}")
print(f"d: {d}")


x = [random.randint(1, 1 << 1023) for i in range(file_length)]

with open("./data/golden.txt", "w") as f:
    for i in range(file_length):
        f.writelines(f'{str(x[i])}\n')
    f.close()

with open("./data/input.txt", "w") as f1:
    f1.write(f'{str(n)}\n')
    f1.write(f'{str(d)}\n')
    for i in range(file_length):
        y = pow(x[i], e, n)
        f1.write(f'{str(y)}\n')
    f1.close()    
# print(f'x[0] = {x[0]}, e = {e}, N = {N}')
# print(f'\n{pow(x[0], e, N)}')